from django.apps import AppConfig


class NavigationConfig(AppConfig):
    name = 'navigation'
